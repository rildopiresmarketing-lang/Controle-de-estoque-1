package com.exemplo.controleestoque;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout list, root;
    EditText search;
    ArrayList<P> ps = new ArrayList<>();
    android.content.SharedPreferences pref;
    String[] marcas = {"Natura", "Boticário", "Avon", "Quem Disse, Berenice", "Outra"};
    P editingProduct;
    ImageView pendingImage;
    String pendingImageUri = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pref = getSharedPreferences("estoque", 0);
        load();
        ui();
    }

    TextView t(String s, int z) {
        TextView x = new TextView(this);
        x.setText(s); x.setTextSize(z); x.setPadding(16, 12, 16, 12);
        return x;
    }
    Button b(String s) { Button x = new Button(this); x.setText(s); return x; }

    void ui() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,12);
        TextView h = t("📦 CONTROLE DE ESTOQUE", 22); h.setTextColor(Color.rgb(123,31,162)); root.addView(h);
        search = new EditText(this); search.setHint("🔍 Pesquisar produto, código ou marca"); root.addView(search);
        LinearLayout a = new LinearLayout(this);
        Button n = b("＋ Produto"), r = b("📊 Resumo");
        a.addView(n, new LinearLayout.LayoutParams(0,-2,1)); a.addView(r, new LinearLayout.LayoutParams(0,-2,1)); root.addView(a);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        n.setOnClickListener(v -> dialog(null)); r.setOnClickListener(v -> summary());
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int c,int d){render(s.toString());} public void afterTextChanged(Editable e){}
        });
        render("");
    }

    void render(String q) {
        list.removeAllViews();
        String query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        for (P p : ps) {
            String z = (p.n+" "+p.c+" "+p.m).toLowerCase(Locale.ROOT);
            if (query.isEmpty() || z.contains(query)) {
                LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(8,8,8,12);
                LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
                if (!p.img.isEmpty()) {
                    ImageView im = new ImageView(this); im.setLayoutParams(new LinearLayout.LayoutParams(100,100)); im.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    try { im.setImageURI(Uri.parse(p.img)); } catch(Exception ignored) {}
                    top.addView(im);
                }
                TextView x = t(p.n+"  •  "+p.q+" un.",18); if(p.q<=2)x.setTextColor(Color.RED); top.addView(x,new LinearLayout.LayoutParams(0,-2,1)); card.addView(top);
                card.addView(t("Código: "+p.c+" | "+p.m,14));
                LinearLayout row=new LinearLayout(this); Button en=b("＋ Entrada"),sa=b("－ Saída"),ed=b("Editar");
                row.addView(en,new LinearLayout.LayoutParams(0,-2,1)); row.addView(sa,new LinearLayout.LayoutParams(0,-2,1)); row.addView(ed,new LinearLayout.LayoutParams(0,-2,1)); card.addView(row);
                en.setOnClickListener(v->move(p,1)); sa.setOnClickListener(v->move(p,-1)); ed.setOnClickListener(v->dialog(p)); list.addView(card);
            }
        }
        if(ps.isEmpty()) list.addView(t("Nenhum produto cadastrado.\nToque em ＋ Produto para começar.",17));
    }

    void dialog(P old) {
        editingProduct = old; pendingImageUri = old == null ? "" : old.img;
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(25,0,25,0);
        EditText n=new EditText(this), c=new EditText(this), q=new EditText(this);
        n.setHint("Nome/descrição"); c.setHint("Código"); q.setHint("Quantidade"); q.setInputType(2);
        Spinner s=new Spinner(this); s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,marcas));
        pendingImage=new ImageView(this); pendingImage.setLayoutParams(new LinearLayout.LayoutParams(-1,220)); pendingImage.setScaleType(ImageView.ScaleType.CENTER_INSIDE); pendingImage.setBackground(new ColorDrawable(Color.LTGRAY));
        Button imageBtn=b("🖼️ Escolher imagem");
        imageBtn.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,1001); });
        l.addView(n); l.addView(c); l.addView(s); l.addView(q); l.addView(pendingImage); l.addView(imageBtn);
        if(old!=null){ n.setText(old.n); c.setText(old.c); q.setText(""+old.q); int idx=Arrays.asList(marcas).indexOf(old.m); if(idx>=0)s.setSelection(idx); if(!old.img.isEmpty())try{pendingImage.setImageURI(Uri.parse(old.img));}catch(Exception ignored){} }
        AlertDialog d=new AlertDialog.Builder(this).setTitle(old==null?"Novo produto":"Editar produto").setView(l).setPositiveButton("Salvar",null).setNegativeButton("Cancelar",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{
            String name=n.getText().toString().trim(), code=c.getText().toString().trim();
            if(name.isEmpty()||code.isEmpty()){Toast.makeText(this,"Preencha nome e código",Toast.LENGTH_SHORT).show();return;}
            int qty=0; try{qty=Integer.parseInt(q.getText().toString()); if(qty<0)qty=0;}catch(Exception ignored){}
            P duplicate=findDuplicate(name,code,old);
            if(old==null && duplicate!=null){ duplicate.q += qty; if(!pendingImageUri.isEmpty())duplicate.img=pendingImageUri; Toast.makeText(this,"Produto já cadastrado: quantidade adicionada ao estoque.",Toast.LENGTH_LONG).show(); }
            else if(old!=null && duplicate!=null){Toast.makeText(this,"Já existe outro produto com esse código ou descrição.",Toast.LENGTH_LONG).show();return;}
            else if(old==null) ps.add(new P(name,code,s.getSelectedItem().toString(),qty,pendingImageUri));
            else {old.n=name;old.c=code;old.m=s.getSelectedItem().toString();old.q=qty;old.img=pendingImageUri;}
            save(); render(search.getText().toString()); d.dismiss();
        })); d.show();
    }

    P findDuplicate(String name,String code,P ignore){
        for(P p:ps){ if(p==ignore)continue; if(p.c.equalsIgnoreCase(code)||p.n.trim().equalsIgnoreCase(name.trim()))return p; } return null;
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data); if(requestCode==1001&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();pendingImageUri=u.toString();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} if(pendingImage!=null)pendingImage.setImageURI(u);}}

    void move(P p,int dir){
        EditText e=new EditText(this);e.setInputType(2);e.setHint("Quantidade");
        new AlertDialog.Builder(this).setTitle(dir>0?"Entrada: "+p.n:"Saída: "+p.n).setView(e).setPositiveButton("Confirmar",(d,w)->{try{int x=Integer.parseInt(e.getText().toString());if(x<=0)return;if(dir<0&&x>p.q){Toast.makeText(this,"Estoque insuficiente",Toast.LENGTH_SHORT).show();return;}p.q+=dir*x;save();render(search.getText().toString());}catch(Exception z){}}).setNegativeButton("Cancelar",null).show();
    }

    void summary(){int u=0,low=0;for(P p:ps){u+=p.q;if(p.q<=2)low++;}new AlertDialog.Builder(this).setTitle("Resumo do estoque").setMessage("Produtos: "+ps.size()+"\nUnidades: "+u+"\nEstoque baixo (≤ 2): "+low).setPositiveButton("OK",null).show();}

    void save(){try{JSONArray a=new JSONArray();for(P p:ps){JSONObject o=new JSONObject();o.put("n",p.n);o.put("c",p.c);o.put("m",p.m);o.put("q",p.q);o.put("img",p.img);a.put(o);}pref.edit().putString("p",a.toString()).apply();}catch(Exception ignored){}}
    void load(){try{JSONArray a=new JSONArray(pref.getString("p","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);ps.add(new P(o.getString("n"),o.getString("c"),o.getString("m"),o.getInt("q"),o.optString("img","")));}}catch(Exception ignored){}}
    static class P{String n,c,m,img;int q;P(String a,String b,String d,int e,String f){n=a;c=b;m=d;q=e;img=f;}}
}
