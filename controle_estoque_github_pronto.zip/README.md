# Controle de Estoque
Projeto Android. Para gerar o APK no GitHub: Actions → Gerar APK → Run workflow. O APK aparece em Artifacts como Controle_Estoque_APK.
